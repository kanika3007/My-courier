import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class GetConnection {
	public static Connection con = null;
	private GetConnection()
	{
		
	}
	public static Connection getConnection(){
		if(con == null) {
			try {
				con = DriverManager.getConnection("jdbc:mysql://localhost:3306/courier","root","Aanshi1507@");
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return con;
		}else {
			return con;	
		}
	}

}