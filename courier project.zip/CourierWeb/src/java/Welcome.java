import java.io.*;
import javax.servlet.http.*;

public class Welcome extends HttpServlet {

    protected void processrequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        out.println("Welcome user");
      }  
}
